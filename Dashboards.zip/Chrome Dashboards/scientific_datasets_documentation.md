# Scientific Mobility Datasets Documentation

This package contains comprehensive datasets for scientific mobility analysis.

## Dataset Overview

### Mobility Base
- **File**: scientific_mobility_base_dataset.csv
- **Description**: Core mobility data with primary POI information and temporal/spatial features
- **Dimensions**: 136,175 rows � 25 columns
- **Users**: 100

### Mobility Poi Matrix
- **File**: scientific_mobility_poi_matrix_dataset.csv
- **Description**: Mobility data with binary POI presence indicators for detailed analysis
- **Dimensions**: 136,175 rows � 55 columns
- **Users**: 100

### Mobility Functional
- **File**: scientific_mobility_functional_dataset.csv
- **Description**: Mobility data with hierarchical functional group categorization
- **Dimensions**: 136,175 rows � 26 columns
- **Users**: 100

### User Profiles
- **File**: scientific_user_profiles_dataset.csv
- **Description**: Aggregated user-level features and mobility patterns
- **Dimensions**: 100 rows � 26 columns
- **Users**: N/A

### Location Profiles
- **File**: scientific_location_profiles_dataset.csv
- **Description**: Aggregated location-level features and visit patterns
- **Dimensions**: 10,495 rows � 15 columns
- **Users**: N/A

## Column Descriptions

### Core Mobility Features
- **user_id**: Unique identifier for each user (0-99 for first 100 users)
- **day**: Day of observation (0-based indexing)
- **time_slot**: Time slot within day (48 slots, 30-minute intervals)
- **hour**: Hour of day (0-23)
- **minute**: Minute within hour (0 or 30)
- **grid_x**: X coordinate in grid system
- **grid_y**: Y coordinate in grid system
- **location_category**: Primary POI category at this location
- **location_function**: Primary functional group at this location
- **poi_density**: Total number of POIs at this location
- **poi_proportion**: Proportion of POIs relative to total area
- **category_diversity**: Number of different POI categories
- **functional_diversity**: Number of different functional groups

### Temporal Features
- **time_period_detailed**: Detailed time period (Early_Morning, Morning_Rush, etc.)
- **day_of_week**: Day of week (0=Monday, 6=Sunday)
- **day_name**: Day name (Monday, Tuesday, etc.)
- **is_weekend**: Boolean indicator for weekend days
- **is_weekday**: Boolean indicator for weekday days

### Spatial Features
- **distance_from_center**: Distance from geographic center of study area
- **distance_quartile**: Spatial zone (Central, Inner, Outer, Peripheral)
- **grid_quadrant**: Grid quadrant (0=SW, 1=NW, 2=SE, 3=NE)
- **grid_quadrant_name**: Grid quadrant name (SW, NW, SE, NE)
- **poi_density_category**: POI density level (None, Low, Medium, High)
- **location_attractiveness**: Composite score of POI density and diversity

## Research Applications

These datasets are designed for:
- **Anomaly Detection**: Identify unusual mobility patterns
- **Temporal Analysis**: Study time-based mobility patterns
- **Spatial Analysis**: Analyze location-based behaviors
- **User Profiling**: Characterize different mobility types
- **Location Profiling**: Understand place characteristics
- **Multi-scale Analysis**: From individual to aggregate patterns

## Data Quality

- **Temporal Coverage**: 75 days
- **Spatial Coverage**: 10495 unique locations
- **User Coverage**: 100 users
- **Total Records**: 136,175 mobility records
- **POI Coverage**: 96.5% of records have POI context

## Usage Notes

1. **Missing Values**: Locations without POIs are marked as 'No_POI'
2. **Time Format**: Time slots are 30-minute intervals (0-47 per day)
3. **Coordinates**: Grid system with arbitrary origin
4. **Privacy**: All data is anonymized and aggregated
5. **Scale**: Suitable for city-scale mobility analysis

